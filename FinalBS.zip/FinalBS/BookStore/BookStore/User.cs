﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore
{
    internal class User
    {
        private string username;
        private string password;

        public string Username { get { return username; } set { username = value; } }
        public string Password { get { return password; } set { password = value; } }

        public User(string username, string password)
        {
            Username = username;
            Password = password;
        }

    }

    internal static class CurrentUserService
    {
        private static User currentUser;

        public static void SetCurrentUser(User user)
        {
            currentUser = user;
        }

        public static User GetCurrentUser()
        {
            return currentUser;
        }
    }
}
