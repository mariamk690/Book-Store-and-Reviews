﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore
{
    internal class Book
    {
        private int bookID;
        private string title;
        private string author;
        private string genre;
        private decimal price;
        private string description;
        private int quantity;
        private string imageURL;

        public int BookID { get { return bookID; } set { bookID = value; } }
        public string Title { get { return title; } set { title = value; } }
        public string Author { get { return author; } set { author = value; } }
        public string Genre { get { return genre; } set { genre = value; } }
        public decimal Price { get { return price; } set { price = value; } }
        public string Description { get { return description; } set { description = value; } }
        public int Quantity { get { return quantity; } set { quantity = value; } }
        public string ImageURL { get { return imageURL; } set { imageURL = value; } }



        public Book(string title, string author, string genre, decimal price, string description, int quantity, string imageURL)
        {
            Title = title;
            Author = author;
            Genre = genre;
            Price = price;
            Description = description;
            Quantity = quantity;
            ImageURL = imageURL;
        }
        public Book(int bookID, string title, string author, string genre, decimal price, string description, int quantity)
        {
            BookID = bookID;
            Title = title;
            Author = author;
            Genre = genre;
            Price = price;
            Description = description;
            Quantity = quantity;
        }

        public Book(int bookID, string title, string author, string genre, decimal price, string description, int quantity, string imageURL)
        {
            BookID = bookID;
            Title = title;
            Author = author;
            Genre = genre;
            Price = price;
            Description = description;
            Quantity = quantity;
            ImageURL = imageURL;
        }

    }
}
