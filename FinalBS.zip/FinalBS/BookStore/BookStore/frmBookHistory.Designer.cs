﻿namespace BookStore
{
    partial class frmBookHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flpBooks = new System.Windows.Forms.FlowLayoutPanel();
            this.panLeftHover = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblBrowseBooks = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnBookHistoryAndReviews = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblBookReviewer = new System.Windows.Forms.Label();
            this.lblInstruction = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // flpBooks
            // 
            this.flpBooks.AutoScroll = true;
            this.flpBooks.Location = new System.Drawing.Point(317, 100);
            this.flpBooks.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flpBooks.Name = "flpBooks";
            this.flpBooks.Size = new System.Drawing.Size(817, 437);
            this.flpBooks.TabIndex = 37;
            // 
            // panLeftHover
            // 
            this.panLeftHover.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panLeftHover.Location = new System.Drawing.Point(224, 454);
            this.panLeftHover.Margin = new System.Windows.Forms.Padding(4);
            this.panLeftHover.Name = "panLeftHover";
            this.panLeftHover.Size = new System.Drawing.Size(7, 186);
            this.panLeftHover.TabIndex = 36;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.lblBrowseBooks);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Font = new System.Drawing.Font("Yu Gothic", 16.125F, System.Drawing.FontStyle.Bold);
            this.panel3.Location = new System.Drawing.Point(224, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(977, 91);
            this.panel3.TabIndex = 35;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnExit);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(874, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(103, 91);
            this.panel4.TabIndex = 2;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.IndianRed;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Yu Gothic", 16.125F, System.Drawing.FontStyle.Bold);
            this.btnExit.ForeColor = System.Drawing.Color.Black;
            this.btnExit.Location = new System.Drawing.Point(0, 0);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(103, 91);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "X";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblBrowseBooks
            // 
            this.lblBrowseBooks.AutoSize = true;
            this.lblBrowseBooks.BackColor = System.Drawing.Color.Transparent;
            this.lblBrowseBooks.Font = new System.Drawing.Font("Yu Gothic", 16.125F, System.Drawing.FontStyle.Bold);
            this.lblBrowseBooks.ForeColor = System.Drawing.Color.Black;
            this.lblBrowseBooks.Location = new System.Drawing.Point(8, 25);
            this.lblBrowseBooks.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBrowseBooks.Name = "lblBrowseBooks";
            this.lblBrowseBooks.Size = new System.Drawing.Size(379, 35);
            this.lblBrowseBooks.TabIndex = 1;
            this.lblBrowseBooks.Text = "Browse Through Our Books";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnBookHistoryAndReviews);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(224, 640);
            this.panel1.TabIndex = 34;
            // 
            // btnBookHistoryAndReviews
            // 
            this.btnBookHistoryAndReviews.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnBookHistoryAndReviews.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBookHistoryAndReviews.Font = new System.Drawing.Font("Yu Gothic", 16.125F, System.Drawing.FontStyle.Bold);
            this.btnBookHistoryAndReviews.ForeColor = System.Drawing.Color.Black;
            this.btnBookHistoryAndReviews.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnBookHistoryAndReviews.Location = new System.Drawing.Point(0, 89);
            this.btnBookHistoryAndReviews.Margin = new System.Windows.Forms.Padding(4);
            this.btnBookHistoryAndReviews.Name = "btnBookHistoryAndReviews";
            this.btnBookHistoryAndReviews.Size = new System.Drawing.Size(224, 551);
            this.btnBookHistoryAndReviews.TabIndex = 3;
            this.btnBookHistoryAndReviews.Text = "Book Purchase History and Reviews";
            this.btnBookHistoryAndReviews.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnBookHistoryAndReviews.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.lblBookReviewer);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(224, 91);
            this.panel2.TabIndex = 0;
            // 
            // lblBookReviewer
            // 
            this.lblBookReviewer.AutoSize = true;
            this.lblBookReviewer.BackColor = System.Drawing.Color.Transparent;
            this.lblBookReviewer.Font = new System.Drawing.Font("Yu Gothic", 17F, System.Drawing.FontStyle.Bold);
            this.lblBookReviewer.ForeColor = System.Drawing.Color.Black;
            this.lblBookReviewer.Location = new System.Drawing.Point(8, 27);
            this.lblBookReviewer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBookReviewer.Name = "lblBookReviewer";
            this.lblBookReviewer.Size = new System.Drawing.Size(198, 38);
            this.lblBookReviewer.TabIndex = 3;
            this.lblBookReviewer.Text = "Book Review";
            // 
            // lblInstruction
            // 
            this.lblInstruction.AutoSize = true;
            this.lblInstruction.Font = new System.Drawing.Font("Yu Gothic", 16.125F, System.Drawing.FontStyle.Bold);
            this.lblInstruction.Location = new System.Drawing.Point(411, 566);
            this.lblInstruction.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInstruction.Name = "lblInstruction";
            this.lblInstruction.Size = new System.Drawing.Size(612, 35);
            this.lblInstruction.TabIndex = 38;
            this.lblInstruction.Text = "Please select a book to view history/reviews.";
            // 
            // frmBookHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1201, 640);
            this.Controls.Add(this.lblInstruction);
            this.Controls.Add(this.flpBooks);
            this.Controls.Add(this.panLeftHover);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmBookHistory";
            this.Text = "frmBookHistory";
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flpBooks;
        private System.Windows.Forms.Panel panLeftHover;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblBrowseBooks;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnBookHistoryAndReviews;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblBookReviewer;
        private System.Windows.Forms.Label lblInstruction;
    }
}