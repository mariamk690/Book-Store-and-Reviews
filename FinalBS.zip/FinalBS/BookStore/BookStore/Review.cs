﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore
{
    internal class Review
    {
        private int reviewID;
        private int bookID;
        private int userID;
        private int rating;
        private string comment;
        private DateTime date;

        public int ReviewID { get { return reviewID; } set { reviewID = value; } }
        public int BookID { get { return bookID; } set { bookID = value; } }
        public int UserID { get { return userID; } set { userID = value; } }
        public int Rating { get { return rating; } set { rating = value; } }
        public string Comment { get { return comment; } set { comment = value; } }
        public DateTime Date { get { return date; } set { date = value; } }

        public Review(int reviewID, int bookID, int userID, int rating, string comment, DateTime date)
        {
            ReviewID = reviewID;
            BookID = bookID;
            UserID = userID;
            Rating = rating;
            Comment = comment;
            Date = date;
        }
    }
}
