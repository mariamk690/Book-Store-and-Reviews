﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore
{
    internal class Order
    {
        private string username;
        private int bookID;
        private decimal totalPrice;
        private DateTime date;


        public string Username { get { return username; } set { username = value; } }
        public int BookID { get { return bookID; } set { bookID = value; } }
        public decimal TotalPrice { get { return totalPrice; } set { totalPrice = value; } }
        public DateTime Date { get { return date; } set { date = value; } }


        public Order(int bookID, string username, decimal totalPrice, DateTime date)
        {
            BookID = bookID;
            Username = username;
            TotalPrice = totalPrice;
            Date = date;
        }
    }
}
