﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookStore
{
    public partial class frmSelectedBookHistory : Form
    {
        private string bookTitle;
        private OleDbConnection myConnection;
        private string strConnection = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=BookData.accdb;";

        public frmSelectedBookHistory(string title)
        {
            InitializeComponent();
            bookTitle = title;
            LoadBookDetails();
        }
        private void LoadBookDetails()
        {
            try
            {
                myConnection = new OleDbConnection(strConnection);
                myConnection.Open();
                string strSQL = "SELECT Title, Author, Genre, Price, Description, Quantity, ImageUrl FROM Book WHERE Title = @Title";
                OleDbCommand myCommand = new OleDbCommand(strSQL, myConnection);
                myCommand.Parameters.AddWithValue("@Title", bookTitle);

                using (OleDbDataReader reader = myCommand.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        // all book details
                        lblTitle.Text = $"Title: {reader["Title"].ToString()}";
                        lblAuthor.Text = $"Author: {reader["Author"].ToString()}";
                        lblGenre.Text = $"Genre: {reader["Genre"].ToString()}";
                        lblPrice.Text = $"Price: ${reader["Price"].ToString()}";

                        // loads cover pic
                        string imageUrl = reader["ImageUrl"].ToString();
                        if (Uri.IsWellFormedUriString(imageUrl, UriKind.Absolute))
                        {
                            try
                            {
                                pbxSelectedBook.Load(imageUrl);
                            }
                            catch
                            {
                                pbxSelectedBook.Image = Properties.Resources.defaultBookImage;
                            }
                        }
                        else
                        {
                            pbxSelectedBook.Image = Properties.Resources.defaultBookImage;
                        }
                        LoadBookHistory();
                        LoadBookReviews();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading book details: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (myConnection != null && myConnection.State == System.Data.ConnectionState.Open)
                {
                    myConnection.Close();
                }
            }
        }

        private void LoadBookHistory()
        {
            using (OleDbConnection connection = new OleDbConnection(strConnection))
            {
                try
                {
                    connection.Open();
                    string strSQL = "SELECT * FROM [Order] WHERE BookTitle = @BookTitle";
                    OleDbCommand myCommand = new OleDbCommand(strSQL, connection);
                    myCommand.Parameters.AddWithValue("@BookTitle", bookTitle);

                    OleDbDataAdapter adapter = new OleDbDataAdapter(myCommand);
                    System.Data.DataTable historyTable = new System.Data.DataTable();
                    adapter.Fill(historyTable);
                    dgvBookHistory.DataSource = historyTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while loading book history: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadBookReviews()
        {
            using (OleDbConnection connection = new OleDbConnection(strConnection))
            {
                try
                {
                    connection.Open();
                    string strSQL = "SELECT * FROM Review WHERE BookTitle = @BookTitle";
                    OleDbCommand myCommand = new OleDbCommand(strSQL, connection);
                    myCommand.Parameters.AddWithValue("@BookTitle", bookTitle);

                    OleDbDataAdapter adapter = new OleDbDataAdapter(myCommand);
                    System.Data.DataTable reviewTable = new System.Data.DataTable();
                    adapter.Fill(reviewTable);
                    dgvBookReviews.DataSource = reviewTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while loading book reviews: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
