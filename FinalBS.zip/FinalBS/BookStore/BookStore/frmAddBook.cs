﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookStore
{
    public partial class frmAddBook : Form
    {
        public frmAddBook()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnBookSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtTitle.Text) ||
                    string.IsNullOrWhiteSpace(txtAuthor.Text) ||
                    string.IsNullOrWhiteSpace(txtGenre.Text) ||
                    string.IsNullOrWhiteSpace(txtDescription.Text) ||
                    string.IsNullOrWhiteSpace(txtImageURL.Text) ||
                    string.IsNullOrWhiteSpace(txtPrice.Text) ||
                    string.IsNullOrWhiteSpace(txtQuantity.Text))
                {
                    MessageBox.Show("Please ensure all fields are filled correctly.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                Book currentBook = new Book
                (
                    txtTitle.Text,
                    txtAuthor.Text,
                    txtGenre.Text,
                    decimal.Parse(txtPrice.Text),
                    txtDescription.Text,
                    int.Parse(txtQuantity.Text),
                    txtImageURL.Text
                );

                bool success = DatabaseOperations.AddBook(currentBook); 

                if (success)
                {
                    MessageBox.Show("Book added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    new frmMain().ShowDialog();
                }
                else
                {
                    MessageBox.Show("Failed to add the book. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // clears txt
            txtTitle.Text = string.Empty;
            txtAuthor.Text = string.Empty;
            txtGenre.Text = string.Empty;
            txtPrice.Text = string.Empty;
            txtDescription.Text = string.Empty;
            txtImageURL.Text = string.Empty;
            txtQuantity.Text = string.Empty;

            // clears pbx
            pbxBookCoverURL.Image = null;
        }

        private void txtImageURL_TextChanged(object sender, EventArgs e)
        {
            // if url not empty
            if (!string.IsNullOrWhiteSpace(txtImageURL.Text))
            {
                try
                {
                    // loads the pic from the irl into the pbx
                    pbxBookCoverURL.Load(txtImageURL.Text);
                }
                catch (Exception)
                {
                    pbxBookCoverURL.Image = null; // no pic if no valid url provided
                }
            }
            else
            {
                pbxBookCoverURL.Image = null; 
            }
        }
    }
}
