﻿namespace BookStore
{
    partial class frmSelectedBookHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSelectedReview = new System.Windows.Forms.Label();
            this.dgvBookReviews = new System.Windows.Forms.DataGridView();
            this.dgvBookHistory = new System.Windows.Forms.DataGridView();
            this.lblSelectedHistoryReviews = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.pbxSelectedBook = new System.Windows.Forms.PictureBox();
            this.lblAuthor = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblGenre = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBookReviews)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBookHistory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSelectedBook)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSelectedReview
            // 
            this.lblSelectedReview.AutoSize = true;
            this.lblSelectedReview.BackColor = System.Drawing.Color.Transparent;
            this.lblSelectedReview.Font = new System.Drawing.Font("Yu Gothic", 19.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedReview.ForeColor = System.Drawing.Color.Black;
            this.lblSelectedReview.Location = new System.Drawing.Point(272, 262);
            this.lblSelectedReview.Name = "lblSelectedReview";
            this.lblSelectedReview.Size = new System.Drawing.Size(273, 35);
            this.lblSelectedReview.TabIndex = 70;
            this.lblSelectedReview.Text = "Selected Reviews...";
            // 
            // dgvBookReviews
            // 
            this.dgvBookReviews.AllowUserToAddRows = false;
            this.dgvBookReviews.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBookReviews.Location = new System.Drawing.Point(273, 301);
            this.dgvBookReviews.Name = "dgvBookReviews";
            this.dgvBookReviews.RowHeadersWidth = 82;
            this.dgvBookReviews.Size = new System.Drawing.Size(576, 182);
            this.dgvBookReviews.TabIndex = 69;
            // 
            // dgvBookHistory
            // 
            this.dgvBookHistory.AllowUserToAddRows = false;
            this.dgvBookHistory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBookHistory.Location = new System.Drawing.Point(273, 71);
            this.dgvBookHistory.Name = "dgvBookHistory";
            this.dgvBookHistory.RowHeadersWidth = 82;
            this.dgvBookHistory.Size = new System.Drawing.Size(576, 179);
            this.dgvBookHistory.TabIndex = 68;
            // 
            // lblSelectedHistoryReviews
            // 
            this.lblSelectedHistoryReviews.AutoSize = true;
            this.lblSelectedHistoryReviews.BackColor = System.Drawing.Color.Transparent;
            this.lblSelectedHistoryReviews.Font = new System.Drawing.Font("Yu Gothic", 19.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedHistoryReviews.ForeColor = System.Drawing.Color.Black;
            this.lblSelectedHistoryReviews.Location = new System.Drawing.Point(267, 37);
            this.lblSelectedHistoryReviews.Name = "lblSelectedHistoryReviews";
            this.lblSelectedHistoryReviews.Size = new System.Drawing.Size(255, 35);
            this.lblSelectedHistoryReviews.TabIndex = 67;
            this.lblSelectedHistoryReviews.Text = "Selected History...";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.IndianRed;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Yu Gothic", 10.125F, System.Drawing.FontStyle.Bold);
            this.btnExit.ForeColor = System.Drawing.Color.Black;
            this.btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExit.Location = new System.Drawing.Point(56, 37);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(125, 62);
            this.btnExit.TabIndex = 66;
            this.btnExit.Text = "Back";
            this.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pbxSelectedBook
            // 
            this.pbxSelectedBook.Location = new System.Drawing.Point(56, 106);
            this.pbxSelectedBook.Name = "pbxSelectedBook";
            this.pbxSelectedBook.Size = new System.Drawing.Size(200, 250);
            this.pbxSelectedBook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxSelectedBook.TabIndex = 65;
            this.pbxSelectedBook.TabStop = false;
            // 
            // lblAuthor
            // 
            this.lblAuthor.AutoSize = true;
            this.lblAuthor.BackColor = System.Drawing.Color.Transparent;
            this.lblAuthor.Font = new System.Drawing.Font("Yu Gothic", 10.125F, System.Drawing.FontStyle.Bold);
            this.lblAuthor.ForeColor = System.Drawing.Color.Black;
            this.lblAuthor.Location = new System.Drawing.Point(53, 396);
            this.lblAuthor.Name = "lblAuthor";
            this.lblAuthor.Size = new System.Drawing.Size(58, 18);
            this.lblAuthor.TabIndex = 64;
            this.lblAuthor.Text = "Author:";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.Transparent;
            this.lblPrice.Font = new System.Drawing.Font("Yu Gothic", 10.125F, System.Drawing.FontStyle.Bold);
            this.lblPrice.ForeColor = System.Drawing.Color.Black;
            this.lblPrice.Location = new System.Drawing.Point(54, 449);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(47, 18);
            this.lblPrice.TabIndex = 63;
            this.lblPrice.Text = "Price:";
            // 
            // lblGenre
            // 
            this.lblGenre.AutoSize = true;
            this.lblGenre.BackColor = System.Drawing.Color.Transparent;
            this.lblGenre.Font = new System.Drawing.Font("Yu Gothic", 10.125F, System.Drawing.FontStyle.Bold);
            this.lblGenre.ForeColor = System.Drawing.Color.Black;
            this.lblGenre.Location = new System.Drawing.Point(53, 422);
            this.lblGenre.Name = "lblGenre";
            this.lblGenre.Size = new System.Drawing.Size(53, 18);
            this.lblGenre.TabIndex = 61;
            this.lblGenre.Text = "Genre:";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.BackColor = System.Drawing.Color.Transparent;
            this.lblTitle.Font = new System.Drawing.Font("Yu Gothic", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.Black;
            this.lblTitle.Location = new System.Drawing.Point(54, 370);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(42, 18);
            this.lblTitle.TabIndex = 60;
            this.lblTitle.Text = "Title:";
            // 
            // SelectedBookHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(901, 520);
            this.Controls.Add(this.lblSelectedReview);
            this.Controls.Add(this.dgvBookReviews);
            this.Controls.Add(this.dgvBookHistory);
            this.Controls.Add(this.lblSelectedHistoryReviews);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.pbxSelectedBook);
            this.Controls.Add(this.lblAuthor);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblGenre);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SelectedBookHistory";
            this.Text = "SelectedBookHistory";
            ((System.ComponentModel.ISupportInitialize)(this.dgvBookReviews)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBookHistory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSelectedBook)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSelectedReview;
        private System.Windows.Forms.DataGridView dgvBookReviews;
        private System.Windows.Forms.DataGridView dgvBookHistory;
        private System.Windows.Forms.Label lblSelectedHistoryReviews;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.PictureBox pbxSelectedBook;
        private System.Windows.Forms.Label lblAuthor;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblGenre;
        private System.Windows.Forms.Label lblTitle;
    }
}