﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookStore
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Session.loggedInUser = txtUsername.Text;
            string password = txtPassword.Text;
            string username = Session.loggedInUser;

            User user = DatabaseOperations.RetrieveUserByUsername(username);

            if (user != null && user.Password == password)
            {
                CurrentUserService.SetCurrentUser(user);

                frmMain frmMain = new frmMain();
                frmMain.ShowDialog();
            }
            else
            {
                MessageBox.Show("Invalid username or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            new frmSignUp().ShowDialog();
        }
    }
}
