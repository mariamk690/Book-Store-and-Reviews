﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace BookStore
{
    public partial class frmEditBooks : Form
    {
        public frmEditBooks()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDeleteBook_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (DataGridViewRow row in dgvBooks.SelectedRows)
                {
                    int bookID = Convert.ToInt32(row.Cells["BookID"].Value);
                    bool success = DatabaseOperations.DeleteBook(bookID);

                    if (success)
                    {
                        dgvBooks.Rows.Remove(row);
                    }
                    else
                    {
                        MessageBox.Show("Failed to delete book with ID: " + bookID);
                    }
                }

                MessageBox.Show("Selected books deleted successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting books: " + ex.Message);
            }
        }
        private void frmEditBooks_Load(object sender, EventArgs e)
        {
            LoadBooks();
        }
        private void LoadBooks()
        {
            try
            {
                List<Book> books = DatabaseOperations.GetAllBooks();

                DataTable bookTable = new DataTable();
                bookTable.Columns.Add("BookID", typeof(int));
                bookTable.Columns.Add("Title", typeof(string));
                bookTable.Columns.Add("Author", typeof(string));
                bookTable.Columns.Add("Genre", typeof(string));
                bookTable.Columns.Add("Price", typeof(decimal));
                bookTable.Columns.Add("Description", typeof(string));
                bookTable.Columns.Add("Quantity", typeof(int));
                bookTable.Columns.Add("ImageURL", typeof(string));

                foreach (var book in books)
                {
                    bookTable.Rows.Add(book.BookID, book.Title, book.Author, book.Genre, book.Price, book.Description, book.Quantity, book.ImageURL);
                }

                dgvBooks.DataSource = bookTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading books: " + ex.Message);
            }
        }

        private void btnSaveEditBooks_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (DataGridViewRow row in dgvBooks.Rows)
                {
                    if (row.IsNewRow) continue;

                    int bookID = Convert.ToInt32(row.Cells["BookID"].Value);
                    string title = row.Cells["Title"].Value.ToString();
                    string author = row.Cells["Author"].Value.ToString();
                    string genre = row.Cells["Genre"].Value.ToString();
                    decimal price = Convert.ToDecimal(row.Cells["Price"].Value);
                    string description = row.Cells["Description"].Value.ToString();
                    int quantity = Convert.ToInt32(row.Cells["Quantity"].Value);
                    string imageURL = row.Cells["ImageURL"].Value.ToString();

                    Book book = new Book(bookID, title, author, genre, price, description, quantity, imageURL);

                    bool success = DatabaseOperations.UpdateBook(book);

                    if (!success)
                    {
                        MessageBox.Show($"Failed to update book with ID: {book.BookID}");
                    }
                }

                MessageBox.Show("Changes saved successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving changes: " + ex.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string searchTitle = txtSearch.Text.Trim();

                if (string.IsNullOrEmpty(searchTitle))
                {
                    // empty search box still loads books
                    LoadBooks();
                }
                else
                {
                    List<Book> books = DatabaseOperations.GetAllBooks();

                    // book title filter, ignores case
                    var filteredBooks = books.Where(book => book.Title.IndexOf(searchTitle, StringComparison.OrdinalIgnoreCase) >= 0).ToList();

                    DataTable bookTable = new DataTable();
                    bookTable.Columns.Add("BookID", typeof(int));
                    bookTable.Columns.Add("Title", typeof(string));
                    bookTable.Columns.Add("Author", typeof(string));
                    bookTable.Columns.Add("Genre", typeof(string));
                    bookTable.Columns.Add("Price", typeof(decimal));
                    bookTable.Columns.Add("Description", typeof(string));
                    bookTable.Columns.Add("Quantity", typeof(int));
                    bookTable.Columns.Add("ImageURL", typeof(string));

                    foreach (var book in filteredBooks)
                    {
                        bookTable.Rows.Add(book.BookID, book.Title, book.Author, book.Genre, book.Price, book.Description, book.Quantity, book.ImageURL);
                    }

                    dgvBooks.DataSource = bookTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error searching for books: " + ex.Message);
            }
        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvBooks.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a book to checkout.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string username = Session.loggedInUser;

                User user = DatabaseOperations.RetrieveUserByUsername(username);
                if (user == null)
                {
                    MessageBox.Show("Failed to retrieve user information.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                foreach (DataGridViewRow selectedRow in dgvBooks.SelectedRows)
                {
                    int bookID = Convert.ToInt32(selectedRow.Cells["BookID"].Value);
                    string title = selectedRow.Cells["Title"].Value.ToString();
                    int availableQuantity = Convert.ToInt32(selectedRow.Cells["Quantity"].Value);
                    decimal price = Convert.ToDecimal(selectedRow.Cells["Price"].Value);

                    if (availableQuantity <= 0)
                    {
                        MessageBox.Show($"The book '{title}' is out of stock.", "Out of Stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        continue;
                    }

                    int checkoutQuantity = 1;

                    decimal totalPrice = price * checkoutQuantity;
                    DateTime orderDate = DateTime.Now;
                    Order newOrder = new Order(bookID, Session.loggedInUser, totalPrice, orderDate);

                    bool orderSuccess = DatabaseOperations.AddOrder(newOrder);

                    if (orderSuccess)
                    {
                        Book book = DatabaseOperations.GetBookByID(bookID);
                        book.Quantity -= checkoutQuantity;
                        bool updateSuccess = DatabaseOperations.UpdateBook(book);

                        if (!updateSuccess)
                        {
                            MessageBox.Show($"Failed to update the quantity for book '{title}'.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            string message = $"Book '{title}' purchased successfully!\n\n" +
                                             $"Order Details:\n" +
                                             $"Date: {orderDate}\n" +
                                             $"Total Price: {totalPrice:C}";
                            MessageBox.Show(message, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show($"Failed to create an order for book '{title}'.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                LoadBooks();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error during checkout: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
