﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookStore
{
    public partial class frmBookHistory : Form
    {
        private OleDbConnection myConnection;
        string strConnection = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=BookData.accdb;";
        public frmBookHistory()
        {
            InitializeComponent();
            LoadBooksIntoFlowLayout();
        }
        private void LoadBooksIntoFlowLayout()
        {
            try
            {
                myConnection = new OleDbConnection(strConnection);
                myConnection.Open();
                string strSQL = "SELECT Title, Author, Genre, Price, Description, Quantity, ImageUrl FROM Book";
                OleDbCommand myCommand = new OleDbCommand(strSQL, myConnection);
                using (OleDbDataReader reader = myCommand.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string title = reader["Title"].ToString();
                        string author = reader["Author"].ToString();
                        string genre = reader["Genre"].ToString();
                        decimal price = (decimal)reader["Price"];
                        string description = reader["Description"].ToString();
                        int quantity = (int)reader["Quantity"];
                        string imageUrl = reader["ImageUrl"].ToString();

                        // panel for book info
                        Panel panel = new Panel();
                        panel.BorderStyle = BorderStyle.FixedSingle;
                        panel.Width = 125;
                        panel.Height = 175;
                        panel.Tag = title;

                        // pbx for bookcover
                        PictureBox pictureBox = new PictureBox();
                        pictureBox.ImageLocation = imageUrl;
                        pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                        pictureBox.Dock = DockStyle.Fill;

                        // clcik event for pbx and panel
                        panel.Click += Book_Click;
                        pictureBox.Click += Book_Click;

                        panel.Controls.Add(pictureBox);
                        flpBooks.Controls.Add(panel);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading books: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // closes connection
                if (myConnection != null && myConnection.State == ConnectionState.Open)
                {
                    myConnection.Close();
                }
            }
        }

        private void Book_Click(object sender, EventArgs e)
        {
            try
            {
                PictureBox pictureBox = sender as PictureBox;
                if (pictureBox != null && pictureBox.Parent != null && pictureBox.Parent.Tag != null)
                {
                    string title = pictureBox.Parent.Tag.ToString();

                    // this passes the title to the new form
                    frmSelectedBookHistory selectedBookHistory = new frmSelectedBookHistory(title);
                    selectedBookHistory.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while processing the book click event: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBrowseBooks_Click(object sender, EventArgs e)
        {
            new frmMain().ShowDialog();
        }

        private void btnEditBooks_Click(object sender, EventArgs e)
        {
            new frmEditBooks().ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
