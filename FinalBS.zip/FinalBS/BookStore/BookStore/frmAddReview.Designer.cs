﻿namespace BookStore
{
    partial class frmAddReview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSubmitReview = new System.Windows.Forms.Button();
            this.lblRating5 = new System.Windows.Forms.Label();
            this.lblOverallRating = new System.Windows.Forms.Label();
            this.lblRating4 = new System.Windows.Forms.Label();
            this.pbx5Three = new System.Windows.Forms.PictureBox();
            this.pbx5Two = new System.Windows.Forms.PictureBox();
            this.pbx5Five = new System.Windows.Forms.PictureBox();
            this.pbx5Four = new System.Windows.Forms.PictureBox();
            this.pbx5One = new System.Windows.Forms.PictureBox();
            this.pbx4Five = new System.Windows.Forms.PictureBox();
            this.pbx4Four = new System.Windows.Forms.PictureBox();
            this.pbx4Three = new System.Windows.Forms.PictureBox();
            this.pbx4Two = new System.Windows.Forms.PictureBox();
            this.pbx4One = new System.Windows.Forms.PictureBox();
            this.lblQuestionFour = new System.Windows.Forms.Label();
            this.rtxReviewComment = new System.Windows.Forms.RichTextBox();
            this.lvlOverallExperience = new System.Windows.Forms.Label();
            this.pbx3Five = new System.Windows.Forms.PictureBox();
            this.pbx3Four = new System.Windows.Forms.PictureBox();
            this.pbx3Three = new System.Windows.Forms.PictureBox();
            this.pbx3Two = new System.Windows.Forms.PictureBox();
            this.pbx3One = new System.Windows.Forms.PictureBox();
            this.lblQuestionThree = new System.Windows.Forms.Label();
            this.pbx2Five = new System.Windows.Forms.PictureBox();
            this.pbx1Five = new System.Windows.Forms.PictureBox();
            this.pbx2Four = new System.Windows.Forms.PictureBox();
            this.pbx1Four = new System.Windows.Forms.PictureBox();
            this.pbx2Three = new System.Windows.Forms.PictureBox();
            this.pbx1Three = new System.Windows.Forms.PictureBox();
            this.pbx2Two = new System.Windows.Forms.PictureBox();
            this.pbx1Two = new System.Windows.Forms.PictureBox();
            this.pbx1One = new System.Windows.Forms.PictureBox();
            this.pbx2One = new System.Windows.Forms.PictureBox();
            this.lblQuestionTwo = new System.Windows.Forms.Label();
            this.lblQuestionOne = new System.Windows.Forms.Label();
            this.lblAddReviews = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.pbxSelectedBook = new System.Windows.Forms.PictureBox();
            this.lblRating2 = new System.Windows.Forms.Label();
            this.lblRating1 = new System.Windows.Forms.Label();
            this.lblRating3 = new System.Windows.Forms.Label();
            this.cbxBookTitles = new System.Windows.Forms.ComboBox();
            this.lblWhatBook = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbx5Three)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx5Two)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx5Five)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx5Four)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx5One)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx4Five)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx4Four)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx4Three)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx4Two)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx4One)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx3Five)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx3Four)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx3Three)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx3Two)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx3One)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx2Five)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx1Five)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx2Four)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx1Four)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx2Three)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx1Three)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx2Two)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx1Two)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx1One)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx2One)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSelectedBook)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSubmitReview
            // 
            this.btnSubmitReview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSubmitReview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubmitReview.Font = new System.Drawing.Font("Yu Gothic", 10.125F, System.Drawing.FontStyle.Bold);
            this.btnSubmitReview.ForeColor = System.Drawing.Color.Black;
            this.btnSubmitReview.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSubmitReview.Location = new System.Drawing.Point(426, 452);
            this.btnSubmitReview.Name = "btnSubmitReview";
            this.btnSubmitReview.Size = new System.Drawing.Size(266, 38);
            this.btnSubmitReview.TabIndex = 137;
            this.btnSubmitReview.Text = "Submit Review";
            this.btnSubmitReview.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSubmitReview.UseVisualStyleBackColor = false;
            this.btnSubmitReview.Click += new System.EventHandler(this.btnSubmitReview_Click);
            // 
            // lblRating5
            // 
            this.lblRating5.AutoSize = true;
            this.lblRating5.BackColor = System.Drawing.Color.Transparent;
            this.lblRating5.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRating5.ForeColor = System.Drawing.Color.Black;
            this.lblRating5.Location = new System.Drawing.Point(508, 330);
            this.lblRating5.Name = "lblRating5";
            this.lblRating5.Size = new System.Drawing.Size(0, 18);
            this.lblRating5.TabIndex = 136;
            // 
            // lblOverallRating
            // 
            this.lblOverallRating.AutoSize = true;
            this.lblOverallRating.BackColor = System.Drawing.Color.Transparent;
            this.lblOverallRating.Font = new System.Drawing.Font("Yu Gothic", 10.875F, System.Drawing.FontStyle.Bold);
            this.lblOverallRating.ForeColor = System.Drawing.Color.Black;
            this.lblOverallRating.Location = new System.Drawing.Point(295, 303);
            this.lblOverallRating.Name = "lblOverallRating";
            this.lblOverallRating.Size = new System.Drawing.Size(553, 19);
            this.lblOverallRating.TabIndex = 135;
            this.lblOverallRating.Text = "5. How often did you find yourself thinking about the book after reading it?";
            // 
            // lblRating4
            // 
            this.lblRating4.AutoSize = true;
            this.lblRating4.BackColor = System.Drawing.Color.Transparent;
            this.lblRating4.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRating4.ForeColor = System.Drawing.Color.Black;
            this.lblRating4.Location = new System.Drawing.Point(508, 278);
            this.lblRating4.Name = "lblRating4";
            this.lblRating4.Size = new System.Drawing.Size(0, 18);
            this.lblRating4.TabIndex = 134;
            // 
            // pbx5Three
            // 
            this.pbx5Three.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx5Three.Location = new System.Drawing.Point(368, 323);
            this.pbx5Three.Name = "pbx5Three";
            this.pbx5Three.Size = new System.Drawing.Size(29, 29);
            this.pbx5Three.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx5Three.TabIndex = 125;
            this.pbx5Three.TabStop = false;
            // 
            // pbx5Two
            // 
            this.pbx5Two.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx5Two.Location = new System.Drawing.Point(333, 323);
            this.pbx5Two.Name = "pbx5Two";
            this.pbx5Two.Size = new System.Drawing.Size(29, 29);
            this.pbx5Two.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx5Two.TabIndex = 122;
            this.pbx5Two.TabStop = false;
            // 
            // pbx5Five
            // 
            this.pbx5Five.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx5Five.Location = new System.Drawing.Point(438, 323);
            this.pbx5Five.Name = "pbx5Five";
            this.pbx5Five.Size = new System.Drawing.Size(29, 29);
            this.pbx5Five.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx5Five.TabIndex = 123;
            this.pbx5Five.TabStop = false;
            // 
            // pbx5Four
            // 
            this.pbx5Four.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx5Four.Location = new System.Drawing.Point(403, 323);
            this.pbx5Four.Name = "pbx5Four";
            this.pbx5Four.Size = new System.Drawing.Size(29, 29);
            this.pbx5Four.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx5Four.TabIndex = 124;
            this.pbx5Four.TabStop = false;
            // 
            // pbx5One
            // 
            this.pbx5One.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx5One.Location = new System.Drawing.Point(298, 323);
            this.pbx5One.Name = "pbx5One";
            this.pbx5One.Size = new System.Drawing.Size(29, 29);
            this.pbx5One.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx5One.TabIndex = 121;
            this.pbx5One.TabStop = false;
            // 
            // pbx4Five
            // 
            this.pbx4Five.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx4Five.Location = new System.Drawing.Point(438, 272);
            this.pbx4Five.Name = "pbx4Five";
            this.pbx4Five.Size = new System.Drawing.Size(29, 27);
            this.pbx4Five.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx4Five.TabIndex = 133;
            this.pbx4Five.TabStop = false;
            // 
            // pbx4Four
            // 
            this.pbx4Four.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx4Four.Location = new System.Drawing.Point(403, 272);
            this.pbx4Four.Name = "pbx4Four";
            this.pbx4Four.Size = new System.Drawing.Size(29, 27);
            this.pbx4Four.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx4Four.TabIndex = 132;
            this.pbx4Four.TabStop = false;
            // 
            // pbx4Three
            // 
            this.pbx4Three.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx4Three.Location = new System.Drawing.Point(368, 272);
            this.pbx4Three.Name = "pbx4Three";
            this.pbx4Three.Size = new System.Drawing.Size(29, 27);
            this.pbx4Three.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx4Three.TabIndex = 131;
            this.pbx4Three.TabStop = false;
            // 
            // pbx4Two
            // 
            this.pbx4Two.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx4Two.Location = new System.Drawing.Point(333, 272);
            this.pbx4Two.Name = "pbx4Two";
            this.pbx4Two.Size = new System.Drawing.Size(29, 27);
            this.pbx4Two.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx4Two.TabIndex = 130;
            this.pbx4Two.TabStop = false;
            // 
            // pbx4One
            // 
            this.pbx4One.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx4One.Location = new System.Drawing.Point(298, 272);
            this.pbx4One.Name = "pbx4One";
            this.pbx4One.Size = new System.Drawing.Size(29, 27);
            this.pbx4One.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx4One.TabIndex = 129;
            this.pbx4One.TabStop = false;
            // 
            // lblQuestionFour
            // 
            this.lblQuestionFour.AutoSize = true;
            this.lblQuestionFour.BackColor = System.Drawing.Color.Transparent;
            this.lblQuestionFour.Font = new System.Drawing.Font("Yu Gothic", 10.875F, System.Drawing.FontStyle.Bold);
            this.lblQuestionFour.ForeColor = System.Drawing.Color.Black;
            this.lblQuestionFour.Location = new System.Drawing.Point(295, 252);
            this.lblQuestionFour.Name = "lblQuestionFour";
            this.lblQuestionFour.Size = new System.Drawing.Size(402, 19);
            this.lblQuestionFour.TabIndex = 128;
            this.lblQuestionFour.Text = "4. How effectively were the book\'s themes conveyed?";
            // 
            // rtxReviewComment
            // 
            this.rtxReviewComment.Location = new System.Drawing.Point(298, 376);
            this.rtxReviewComment.Name = "rtxReviewComment";
            this.rtxReviewComment.Size = new System.Drawing.Size(535, 61);
            this.rtxReviewComment.TabIndex = 127;
            this.rtxReviewComment.Text = "";
            // 
            // lvlOverallExperience
            // 
            this.lvlOverallExperience.AutoSize = true;
            this.lvlOverallExperience.BackColor = System.Drawing.Color.Transparent;
            this.lvlOverallExperience.Font = new System.Drawing.Font("Yu Gothic", 10.875F, System.Drawing.FontStyle.Bold);
            this.lvlOverallExperience.ForeColor = System.Drawing.Color.Black;
            this.lvlOverallExperience.Location = new System.Drawing.Point(295, 356);
            this.lvlOverallExperience.Name = "lvlOverallExperience";
            this.lvlOverallExperience.Size = new System.Drawing.Size(362, 19);
            this.lvlOverallExperience.TabIndex = 126;
            this.lvlOverallExperience.Text = "6. What were your overall thoughts on the book?";
            // 
            // pbx3Five
            // 
            this.pbx3Five.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx3Five.Location = new System.Drawing.Point(438, 218);
            this.pbx3Five.Name = "pbx3Five";
            this.pbx3Five.Size = new System.Drawing.Size(29, 27);
            this.pbx3Five.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx3Five.TabIndex = 120;
            this.pbx3Five.TabStop = false;
            // 
            // pbx3Four
            // 
            this.pbx3Four.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx3Four.Location = new System.Drawing.Point(402, 218);
            this.pbx3Four.Name = "pbx3Four";
            this.pbx3Four.Size = new System.Drawing.Size(29, 27);
            this.pbx3Four.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx3Four.TabIndex = 119;
            this.pbx3Four.TabStop = false;
            // 
            // pbx3Three
            // 
            this.pbx3Three.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx3Three.Location = new System.Drawing.Point(368, 218);
            this.pbx3Three.Name = "pbx3Three";
            this.pbx3Three.Size = new System.Drawing.Size(29, 27);
            this.pbx3Three.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx3Three.TabIndex = 118;
            this.pbx3Three.TabStop = false;
            // 
            // pbx3Two
            // 
            this.pbx3Two.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx3Two.Location = new System.Drawing.Point(332, 218);
            this.pbx3Two.Name = "pbx3Two";
            this.pbx3Two.Size = new System.Drawing.Size(29, 27);
            this.pbx3Two.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx3Two.TabIndex = 117;
            this.pbx3Two.TabStop = false;
            // 
            // pbx3One
            // 
            this.pbx3One.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx3One.Location = new System.Drawing.Point(298, 218);
            this.pbx3One.Name = "pbx3One";
            this.pbx3One.Size = new System.Drawing.Size(29, 27);
            this.pbx3One.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx3One.TabIndex = 116;
            this.pbx3One.TabStop = false;
            // 
            // lblQuestionThree
            // 
            this.lblQuestionThree.AutoSize = true;
            this.lblQuestionThree.BackColor = System.Drawing.Color.Transparent;
            this.lblQuestionThree.Font = new System.Drawing.Font("Yu Gothic", 10.875F, System.Drawing.FontStyle.Bold);
            this.lblQuestionThree.ForeColor = System.Drawing.Color.Black;
            this.lblQuestionThree.Location = new System.Drawing.Point(294, 197);
            this.lblQuestionThree.Name = "lblQuestionThree";
            this.lblQuestionThree.Size = new System.Drawing.Size(375, 19);
            this.lblQuestionThree.TabIndex = 115;
            this.lblQuestionThree.Text = "3. How well-developed were the main characters?";
            // 
            // pbx2Five
            // 
            this.pbx2Five.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx2Five.Location = new System.Drawing.Point(438, 167);
            this.pbx2Five.Name = "pbx2Five";
            this.pbx2Five.Size = new System.Drawing.Size(29, 27);
            this.pbx2Five.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx2Five.TabIndex = 114;
            this.pbx2Five.TabStop = false;
            // 
            // pbx1Five
            // 
            this.pbx1Five.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx1Five.Location = new System.Drawing.Point(438, 116);
            this.pbx1Five.Name = "pbx1Five";
            this.pbx1Five.Size = new System.Drawing.Size(29, 27);
            this.pbx1Five.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx1Five.TabIndex = 109;
            this.pbx1Five.TabStop = false;
            // 
            // pbx2Four
            // 
            this.pbx2Four.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx2Four.Location = new System.Drawing.Point(402, 167);
            this.pbx2Four.Name = "pbx2Four";
            this.pbx2Four.Size = new System.Drawing.Size(29, 27);
            this.pbx2Four.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx2Four.TabIndex = 113;
            this.pbx2Four.TabStop = false;
            // 
            // pbx1Four
            // 
            this.pbx1Four.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx1Four.Location = new System.Drawing.Point(402, 116);
            this.pbx1Four.Name = "pbx1Four";
            this.pbx1Four.Size = new System.Drawing.Size(29, 27);
            this.pbx1Four.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx1Four.TabIndex = 108;
            this.pbx1Four.TabStop = false;
            // 
            // pbx2Three
            // 
            this.pbx2Three.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx2Three.Location = new System.Drawing.Point(368, 167);
            this.pbx2Three.Name = "pbx2Three";
            this.pbx2Three.Size = new System.Drawing.Size(29, 27);
            this.pbx2Three.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx2Three.TabIndex = 112;
            this.pbx2Three.TabStop = false;
            // 
            // pbx1Three
            // 
            this.pbx1Three.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx1Three.Location = new System.Drawing.Point(368, 116);
            this.pbx1Three.Name = "pbx1Three";
            this.pbx1Three.Size = new System.Drawing.Size(29, 27);
            this.pbx1Three.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx1Three.TabIndex = 107;
            this.pbx1Three.TabStop = false;
            // 
            // pbx2Two
            // 
            this.pbx2Two.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx2Two.Location = new System.Drawing.Point(332, 167);
            this.pbx2Two.Name = "pbx2Two";
            this.pbx2Two.Size = new System.Drawing.Size(29, 27);
            this.pbx2Two.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx2Two.TabIndex = 111;
            this.pbx2Two.TabStop = false;
            // 
            // pbx1Two
            // 
            this.pbx1Two.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx1Two.Location = new System.Drawing.Point(332, 116);
            this.pbx1Two.Name = "pbx1Two";
            this.pbx1Two.Size = new System.Drawing.Size(29, 27);
            this.pbx1Two.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx1Two.TabIndex = 105;
            this.pbx1Two.TabStop = false;
            // 
            // pbx1One
            // 
            this.pbx1One.ErrorImage = null;
            this.pbx1One.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx1One.Location = new System.Drawing.Point(298, 116);
            this.pbx1One.Name = "pbx1One";
            this.pbx1One.Size = new System.Drawing.Size(29, 27);
            this.pbx1One.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx1One.TabIndex = 104;
            this.pbx1One.TabStop = false;
            // 
            // pbx2One
            // 
            this.pbx2One.Image = global::BookStore.Properties.Resources.empty_star;
            this.pbx2One.Location = new System.Drawing.Point(298, 167);
            this.pbx2One.Name = "pbx2One";
            this.pbx2One.Size = new System.Drawing.Size(29, 27);
            this.pbx2One.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbx2One.TabIndex = 110;
            this.pbx2One.TabStop = false;
            // 
            // lblQuestionTwo
            // 
            this.lblQuestionTwo.AutoSize = true;
            this.lblQuestionTwo.BackColor = System.Drawing.Color.Transparent;
            this.lblQuestionTwo.Font = new System.Drawing.Font("Yu Gothic", 10.875F, System.Drawing.FontStyle.Bold);
            this.lblQuestionTwo.ForeColor = System.Drawing.Color.Black;
            this.lblQuestionTwo.Location = new System.Drawing.Point(294, 146);
            this.lblQuestionTwo.Name = "lblQuestionTwo";
            this.lblQuestionTwo.Size = new System.Drawing.Size(312, 19);
            this.lblQuestionTwo.TabIndex = 106;
            this.lblQuestionTwo.Text = "2. How satisfying was the story’s ending?";
            // 
            // lblQuestionOne
            // 
            this.lblQuestionOne.AutoSize = true;
            this.lblQuestionOne.BackColor = System.Drawing.Color.Transparent;
            this.lblQuestionOne.Font = new System.Drawing.Font("Yu Gothic", 10.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuestionOne.ForeColor = System.Drawing.Color.Black;
            this.lblQuestionOne.Location = new System.Drawing.Point(294, 99);
            this.lblQuestionOne.Name = "lblQuestionOne";
            this.lblQuestionOne.Size = new System.Drawing.Size(295, 19);
            this.lblQuestionOne.TabIndex = 103;
            this.lblQuestionOne.Text = "1. How engaging was the book overall?";
            // 
            // lblAddReviews
            // 
            this.lblAddReviews.AutoSize = true;
            this.lblAddReviews.BackColor = System.Drawing.Color.Transparent;
            this.lblAddReviews.Font = new System.Drawing.Font("Yu Gothic", 19.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddReviews.ForeColor = System.Drawing.Color.Black;
            this.lblAddReviews.Location = new System.Drawing.Point(262, 43);
            this.lblAddReviews.Name = "lblAddReviews";
            this.lblAddReviews.Size = new System.Drawing.Size(253, 35);
            this.lblAddReviews.TabIndex = 102;
            this.lblAddReviews.Text = "Add your review...";
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.IndianRed;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.Font = new System.Drawing.Font("Yu Gothic", 10.125F, System.Drawing.FontStyle.Bold);
            this.btnExit.ForeColor = System.Drawing.Color.Black;
            this.btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnExit.Location = new System.Drawing.Point(74, 31);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(125, 62);
            this.btnExit.TabIndex = 101;
            this.btnExit.Text = "Back";
            this.btnExit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // pbxSelectedBook
            // 
            this.pbxSelectedBook.Location = new System.Drawing.Point(74, 125);
            this.pbxSelectedBook.Name = "pbxSelectedBook";
            this.pbxSelectedBook.Size = new System.Drawing.Size(200, 250);
            this.pbxSelectedBook.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxSelectedBook.TabIndex = 100;
            this.pbxSelectedBook.TabStop = false;
            // 
            // lblRating2
            // 
            this.lblRating2.AutoSize = true;
            this.lblRating2.BackColor = System.Drawing.Color.Transparent;
            this.lblRating2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRating2.ForeColor = System.Drawing.Color.Black;
            this.lblRating2.Location = new System.Drawing.Point(505, 175);
            this.lblRating2.Name = "lblRating2";
            this.lblRating2.Size = new System.Drawing.Size(0, 18);
            this.lblRating2.TabIndex = 138;
            // 
            // lblRating1
            // 
            this.lblRating1.AutoSize = true;
            this.lblRating1.BackColor = System.Drawing.Color.Transparent;
            this.lblRating1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRating1.ForeColor = System.Drawing.Color.Black;
            this.lblRating1.Location = new System.Drawing.Point(505, 124);
            this.lblRating1.Name = "lblRating1";
            this.lblRating1.Size = new System.Drawing.Size(0, 18);
            this.lblRating1.TabIndex = 138;
            // 
            // lblRating3
            // 
            this.lblRating3.AutoSize = true;
            this.lblRating3.BackColor = System.Drawing.Color.Transparent;
            this.lblRating3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRating3.ForeColor = System.Drawing.Color.Black;
            this.lblRating3.Location = new System.Drawing.Point(506, 226);
            this.lblRating3.Name = "lblRating3";
            this.lblRating3.Size = new System.Drawing.Size(0, 18);
            this.lblRating3.TabIndex = 139;
            // 
            // cbxBookTitles
            // 
            this.cbxBookTitles.Font = new System.Drawing.Font("Yu Gothic", 10.875F, System.Drawing.FontStyle.Bold);
            this.cbxBookTitles.FormattingEnabled = true;
            this.cbxBookTitles.Location = new System.Drawing.Point(544, 75);
            this.cbxBookTitles.Name = "cbxBookTitles";
            this.cbxBookTitles.Size = new System.Drawing.Size(239, 26);
            this.cbxBookTitles.TabIndex = 141;
            this.cbxBookTitles.SelectedIndexChanged += new System.EventHandler(this.cbxBookTitles_SelectedIndexChanged);
            // 
            // lblWhatBook
            // 
            this.lblWhatBook.AutoSize = true;
            this.lblWhatBook.BackColor = System.Drawing.Color.Transparent;
            this.lblWhatBook.Font = new System.Drawing.Font("Yu Gothic", 10.875F, System.Drawing.FontStyle.Bold);
            this.lblWhatBook.ForeColor = System.Drawing.Color.Black;
            this.lblWhatBook.Location = new System.Drawing.Point(251, 78);
            this.lblWhatBook.Name = "lblWhatBook";
            this.lblWhatBook.Size = new System.Drawing.Size(282, 19);
            this.lblWhatBook.TabIndex = 140;
            this.lblWhatBook.Text = "Which book would you like to review?";
            // 
            // frmAddReview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(901, 520);
            this.Controls.Add(this.cbxBookTitles);
            this.Controls.Add(this.lblWhatBook);
            this.Controls.Add(this.lblRating3);
            this.Controls.Add(this.lblRating1);
            this.Controls.Add(this.lblRating2);
            this.Controls.Add(this.btnSubmitReview);
            this.Controls.Add(this.lblRating5);
            this.Controls.Add(this.lblOverallRating);
            this.Controls.Add(this.lblRating4);
            this.Controls.Add(this.pbx5Three);
            this.Controls.Add(this.pbx5Two);
            this.Controls.Add(this.pbx5Five);
            this.Controls.Add(this.pbx5Four);
            this.Controls.Add(this.pbx5One);
            this.Controls.Add(this.pbx4Five);
            this.Controls.Add(this.pbx4Four);
            this.Controls.Add(this.pbx4Three);
            this.Controls.Add(this.pbx4Two);
            this.Controls.Add(this.pbx4One);
            this.Controls.Add(this.lblQuestionFour);
            this.Controls.Add(this.rtxReviewComment);
            this.Controls.Add(this.lvlOverallExperience);
            this.Controls.Add(this.pbx3Five);
            this.Controls.Add(this.pbx3Four);
            this.Controls.Add(this.pbx3Three);
            this.Controls.Add(this.pbx3Two);
            this.Controls.Add(this.pbx3One);
            this.Controls.Add(this.lblQuestionThree);
            this.Controls.Add(this.pbx2Five);
            this.Controls.Add(this.pbx1Five);
            this.Controls.Add(this.pbx2Four);
            this.Controls.Add(this.pbx1Four);
            this.Controls.Add(this.pbx2Three);
            this.Controls.Add(this.pbx1Three);
            this.Controls.Add(this.pbx2Two);
            this.Controls.Add(this.pbx1Two);
            this.Controls.Add(this.pbx1One);
            this.Controls.Add(this.pbx2One);
            this.Controls.Add(this.lblQuestionTwo);
            this.Controls.Add(this.lblQuestionOne);
            this.Controls.Add(this.lblAddReviews);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.pbxSelectedBook);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmAddReview";
            this.Text = "frmAddReview";
            ((System.ComponentModel.ISupportInitialize)(this.pbx5Three)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx5Two)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx5Five)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx5Four)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx5One)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx4Five)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx4Four)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx4Three)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx4Two)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx4One)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx3Five)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx3Four)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx3Three)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx3Two)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx3One)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx2Five)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx1Five)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx2Four)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx1Four)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx2Three)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx1Three)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx2Two)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx1Two)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx1One)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx2One)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxSelectedBook)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSubmitReview;
        private System.Windows.Forms.Label lblRating5;
        private System.Windows.Forms.Label lblOverallRating;
        private System.Windows.Forms.Label lblRating4;
        private System.Windows.Forms.PictureBox pbx5Three;
        private System.Windows.Forms.PictureBox pbx5Two;
        private System.Windows.Forms.PictureBox pbx5Five;
        private System.Windows.Forms.PictureBox pbx5Four;
        private System.Windows.Forms.PictureBox pbx5One;
        private System.Windows.Forms.PictureBox pbx4Five;
        private System.Windows.Forms.PictureBox pbx4Four;
        private System.Windows.Forms.PictureBox pbx4Three;
        private System.Windows.Forms.PictureBox pbx4Two;
        private System.Windows.Forms.PictureBox pbx4One;
        private System.Windows.Forms.Label lblQuestionFour;
        private System.Windows.Forms.RichTextBox rtxReviewComment;
        private System.Windows.Forms.Label lvlOverallExperience;
        private System.Windows.Forms.PictureBox pbx3Five;
        private System.Windows.Forms.PictureBox pbx3Four;
        private System.Windows.Forms.PictureBox pbx3Three;
        private System.Windows.Forms.PictureBox pbx3Two;
        private System.Windows.Forms.PictureBox pbx3One;
        private System.Windows.Forms.Label lblQuestionThree;
        private System.Windows.Forms.PictureBox pbx2Five;
        private System.Windows.Forms.PictureBox pbx1Five;
        private System.Windows.Forms.PictureBox pbx2Four;
        private System.Windows.Forms.PictureBox pbx1Four;
        private System.Windows.Forms.PictureBox pbx2Three;
        private System.Windows.Forms.PictureBox pbx1Three;
        private System.Windows.Forms.PictureBox pbx2Two;
        private System.Windows.Forms.PictureBox pbx1Two;
        private System.Windows.Forms.PictureBox pbx1One;
        private System.Windows.Forms.PictureBox pbx2One;
        private System.Windows.Forms.Label lblQuestionTwo;
        private System.Windows.Forms.Label lblQuestionOne;
        private System.Windows.Forms.Label lblAddReviews;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.PictureBox pbxSelectedBook;
        private System.Windows.Forms.Label lblRating2;
        private System.Windows.Forms.Label lblRating1;
        private System.Windows.Forms.Label lblRating3;
        private System.Windows.Forms.ComboBox cbxBookTitles;
        private System.Windows.Forms.Label lblWhatBook;
    }
}