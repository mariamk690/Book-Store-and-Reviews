﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookStore
{
    public partial class frmMain : Form
    {
        private OleDbConnection myConnection;
        string strConnection = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=BookData.accdb;";
        public frmMain()
        {
            InitializeComponent();
            LoadBooksIntoFlowLayout();
        }
        private void LoadBooksIntoFlowLayout()
        {
            try
            {
                myConnection = new OleDbConnection(strConnection);
                myConnection.Open();
                string strSQL = "SELECT Title, Author, Genre, Price, Description, Quantity, ImageUrl FROM Book";
                OleDbCommand myCommand = new OleDbCommand(strSQL, myConnection);
                using (OleDbDataReader reader = myCommand.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string title = reader["Title"].ToString();
                        string author = reader["Author"].ToString();
                        string genre = reader["Genre"].ToString();
                        decimal price = (decimal)reader["Price"];
                        string description = reader["Description"].ToString();
                        int quantity = (int)reader["Quantity"];
                        string imageUrl = reader["ImageUrl"].ToString();

                        // panel for book info
                        Panel panel = new Panel();
                        panel.BorderStyle = BorderStyle.FixedSingle;
                        panel.Width = 125;
                        panel.Height = 175;
                        panel.Tag = title;

                        // creates pbx
                        PictureBox pictureBox = new PictureBox();
                        pictureBox.ImageLocation = imageUrl;
                        pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                        pictureBox.Dock = DockStyle.Fill;

                        panel.Controls.Add(pictureBox);
                        flpBooks.Controls.Add(panel);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading books: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // closes connection
                if (myConnection != null && myConnection.State == ConnectionState.Open)
                {
                    myConnection.Close();
                }
            }
        }


        private void btnAddBook_Click(object sender, EventArgs e)
        {
            new frmAddBook().ShowDialog();
        }

        private void btnAddReview_Click(object sender, EventArgs e)
        {
            new frmAddReview().ShowDialog();
        }

        private void btnEditBooks_Click(object sender, EventArgs e)
        {
            new frmEditBooks().ShowDialog();
        }

        private void btnBookHistoryAndReviews_Click(object sender, EventArgs e)
        {
            new frmBookHistory().ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
