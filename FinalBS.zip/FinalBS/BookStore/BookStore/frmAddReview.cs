﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace BookStore
{
    public partial class frmAddReview : Form
    {
        private OleDbConnection myConnection;
        private string strConnection = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=BookData.accdb;";
        private Dictionary<PictureBox[], Label> starGroups;
        private int currentStarRating;
        private User currentUser;

        public frmAddReview()
        {
            InitializeComponent();
            FillCbxBookTitles();
            currentUser = CurrentUserService.GetCurrentUser();

            starGroups = new Dictionary<PictureBox[], Label>
            {
                { new PictureBox[] { pbx1One, pbx1Two, pbx1Three, pbx1Four, pbx1Five }, lblRating1 },
                { new PictureBox[] { pbx2One, pbx2Two, pbx2Three, pbx2Four, pbx2Five }, lblRating2 },
                { new PictureBox[] { pbx3One, pbx3Two, pbx3Three, pbx3Four, pbx3Five }, lblRating3 },
                { new PictureBox[] { pbx4One, pbx4Two, pbx4Three, pbx4Four, pbx4Five }, lblRating4 },
                { new PictureBox[] { pbx5One, pbx5Two, pbx5Three, pbx5Four, pbx5Five }, lblRating5 },
            };

            foreach (var group in starGroups)
            {
                foreach (var star in group.Key)
                {
                    star.Click += Star_Click;
                }
            }
        }

        private void Star_Click(object sender, EventArgs e)
        {
            var group = starGroups.First(g => g.Key.Contains(sender as PictureBox));
            var stars = group.Key;
            var label = group.Value;

            currentStarRating = Array.IndexOf(stars, sender as PictureBox) + 1;
            for (int i = 0; i < stars.Length; i++)
            {
                stars[i].Image = i < currentStarRating ? Properties.Resources.filled_star : Properties.Resources.empty_star;
            }

            label.Text = $"{currentStarRating} Star{(currentStarRating == 1 ? "" : "s")}";
        }

        private void FillCbxBookTitles()
        {
            try
            {
                using (myConnection = new OleDbConnection(strConnection))
                {
                    myConnection.Open();
                    string query = "SELECT Title FROM Book";
                    OleDbCommand command = new OleDbCommand(query, myConnection);
                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cbxBookTitles.Items.Add(reader["Title"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading book titles: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSubmitReview_Click(object sender, EventArgs e)
        {
            string bookTitle = cbxBookTitles.SelectedItem?.ToString();
            int questionOneRating = GetStarRating(lblRating1);
            int questionTwoRating = GetStarRating(lblRating2);
            int questionThreeRating = GetStarRating(lblRating3);
            int questionFourRating = GetStarRating(lblRating4);
            int questionFiveRating = GetStarRating(lblRating5);
            string reviewComment = rtxReviewComment.Text;

            if (string.IsNullOrWhiteSpace(bookTitle))
            {
                MessageBox.Show("Please select a book title from the list.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (questionOneRating == 0 || questionTwoRating == 0 || questionThreeRating == 0 || questionFourRating == 0 || questionFiveRating == 0)
            {
                MessageBox.Show("Please rate all questions.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (string.IsNullOrWhiteSpace(reviewComment))
            {
                MessageBox.Show("Please enter a comment for your review.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (myConnection = new OleDbConnection(strConnection))
                {
                    myConnection.Open();
                    string query = "INSERT INTO Review (Username, BookTitle, QuestionOne, QuestionTwo, QuestionThree, QuestionFour, QuestionFive, ReviewComment) " +
                    "VALUES (@Username, @BookTitle, @QuestionOne, @QuestionTwo, @QuestionThree, @QuestionFour, @QuestionFive, @ReviewComment)";


                    OleDbCommand command = new OleDbCommand(query, myConnection);
                    command.Parameters.AddWithValue("@Username", currentUser.Username);
                    command.Parameters.AddWithValue("@BookTitle", bookTitle);
                    command.Parameters.AddWithValue("@QuestionOne", questionOneRating);
                    command.Parameters.AddWithValue("@QuestionTwo", questionTwoRating);
                    command.Parameters.AddWithValue("@QuestionThree", questionThreeRating);
                    command.Parameters.AddWithValue("@QuestionFour", questionFourRating);
                    command.Parameters.AddWithValue("@QuestionFive", questionFiveRating);
                    command.Parameters.AddWithValue("@ReviewComment", reviewComment);


                    command.ExecuteNonQuery();
                    MessageBox.Show("Review submitted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearFormFields();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error submitting review: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int GetStarRating(Label label)
        {
            if (int.TryParse(label.Text.Split(' ')[0], out int rating))
            {
                return rating;
            }
            return 0;
        }

        private void ClearFormFields()
        {
            cbxBookTitles.SelectedIndex = -1;
            foreach (var group in starGroups)
            {
                foreach (var star in group.Key)
                {
                    star.Image = Properties.Resources.empty_star;
                }
                group.Value.Text = "";
            }
            rtxReviewComment.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cbxBookTitles_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxBookTitles.SelectedIndex == -1) return;

            string selectedTitle = cbxBookTitles.SelectedItem.ToString();

            try
            {
                using (myConnection = new OleDbConnection(strConnection))
                {
                    myConnection.Open();
                    string query = "SELECT ImageURL FROM Book WHERE Title = @Title";
                    OleDbCommand command = new OleDbCommand(query, myConnection);
                    command.Parameters.AddWithValue("@Title", selectedTitle);

                    string imageURL = command.ExecuteScalar() as string;

                    if (!string.IsNullOrWhiteSpace(imageURL))
                    {
                        pbxSelectedBook.Load(imageURL);
                    }
                    else
                    {
                        pbxSelectedBook.Image = null;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading book image: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
