﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore
{
    internal static class DatabaseOperations
    {
        private static string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=BookData.accdb;";

        // ---------------- Book CRUD ----------------

        // Create
        public static bool AddBook(Book book)
        {
            string query = "INSERT INTO Book (Title, Author, Genre, Price, Description, Quantity, ImageUrl) " +
                           "VALUES (@Title, @Author, @Genre, @Price, @Description, @Quantity, @ImageUrl)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                OleDbCommand command = new OleDbCommand(query, connection);
                command.Parameters.AddWithValue("@Title", book.Title);
                command.Parameters.AddWithValue("@Author", book.Author);
                command.Parameters.AddWithValue("@Genre", book.Genre);
                command.Parameters.AddWithValue("@Price", book.Price);
                command.Parameters.AddWithValue("@Description", book.Description);
                command.Parameters.AddWithValue("@Quantity", book.Quantity);
                command.Parameters.AddWithValue("@ImageUrl", book.ImageURL);
                connection.Open();
                return command.ExecuteNonQuery() > 0;
            }
        }


        // Read (All Books)
        public static List<Book> GetAllBooks()
        {
            List<Book> books = new List<Book>();
            string query = "SELECT * FROM Book";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                OleDbCommand command = new OleDbCommand(query, connection);
                connection.Open();

                using (OleDbDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        books.Add(new Book(
                            Convert.ToInt32(reader["BookID"]),
                            reader["Title"].ToString(),
                            reader["Author"].ToString(),
                            reader["Genre"].ToString(),
                            Convert.ToDecimal(reader["Price"]),
                            reader["Description"].ToString(),
                            Convert.ToInt32(reader["Quantity"])
                        ));
                    }
                }
            }

            return books;
        }

        // Read (Single Book)
        public static Book GetBookByID(int bookID)
        {
            string query = "SELECT * FROM Book WHERE BookID = @BookID";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                OleDbCommand command = new OleDbCommand(query, connection);
                command.Parameters.AddWithValue("@BookID", bookID);
                connection.Open();

                using (OleDbDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new Book(
                            Convert.ToInt32(reader["BookID"]),
                            reader["Title"].ToString(),
                            reader["Author"].ToString(),
                            reader["Genre"].ToString(),
                            Convert.ToDecimal(reader["Price"]),
                            reader["Description"].ToString(),
                            Convert.ToInt32(reader["Quantity"])
                        );
                    }
                }
            }

            return null;
        }

        // Update
        public static bool UpdateBook(Book book)
        {
            string query = "UPDATE Book SET Title = @Title, Author = @Author, Genre = @Genre, " +
                           "Price = @Price, Description = @Description, Quantity = @Quantity " +
                           "WHERE BookID = @BookID";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                OleDbCommand command = new OleDbCommand(query, connection);
                command.Parameters.AddWithValue("@Title", book.Title);
                command.Parameters.AddWithValue("@Author", book.Author);
                command.Parameters.AddWithValue("@Genre", book.Genre);
                command.Parameters.AddWithValue("@Price", book.Price);
                command.Parameters.AddWithValue("@Description", book.Description);
                command.Parameters.AddWithValue("@Quantity", book.Quantity);
                command.Parameters.AddWithValue("@BookID", book.BookID);

                connection.Open();
                return command.ExecuteNonQuery() > 0;
            }
        }

        // Delete
        public static bool DeleteBook(int bookID)
        {
            string query = "DELETE FROM Book WHERE BookID = @BookID";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                OleDbCommand command = new OleDbCommand(query, connection);
                command.Parameters.AddWithValue("@BookID", bookID);

                connection.Open();
                return command.ExecuteNonQuery() > 0;
            }
        }

        // ---------------- User CRUD ----------------

        // Create
        public static bool AddUser(User user)
        {
            string query = "INSERT INTO [User] ([Username], [Password]) VALUES (@Username, @Password)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                OleDbCommand command = new OleDbCommand(query, connection);
                command.Parameters.AddWithValue("@Username", user.Username);
                command.Parameters.AddWithValue("@Password", user.Password);

                try
                {
                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                    return false;
                }
            }
        }

        

        // Read (Single User)
        public static User RetrieveUserByUsername(string username)
        {
            string query = "SELECT * FROM [User] WHERE [Username] = @Username";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                OleDbCommand command = new OleDbCommand(query, connection);
                command.Parameters.AddWithValue("@Username", username);
                connection.Open();

                using (OleDbDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new User(
                            reader["Username"].ToString(),
                            reader["Password"].ToString()
                        );
                    }
                }
            }

            return null;
        }

        // Delete
        public static bool DeleteUser(int userID)
        {
            string query = "DELETE FROM User WHERE UserID = @UserID";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                OleDbCommand command = new OleDbCommand(query, connection);
                command.Parameters.AddWithValue("@UserID", userID);

                connection.Open();
                return command.ExecuteNonQuery() > 0;
            }
        }

        public static bool AddOrder(Order order)
        {
            string query = "INSERT INTO [Order] (BookID, Username, TotalPrice, OrderDate) " +
                           "VALUES (@BookID, @Username, @TotalPrice, @OrderDate)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                OleDbCommand command = new OleDbCommand(query, connection);
                command.Parameters.AddWithValue("@BookID", order.BookID);
                command.Parameters.AddWithValue("@Username", order.Username); 
                command.Parameters.AddWithValue("@TotalPrice", (double)order.TotalPrice); 
                command.Parameters.AddWithValue("@OrderDate", order.Date.ToString("yyyy-MM-dd HH:mm:ss"));

                try
                {
                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
                catch (Exception ex)
                {
                    throw new Exception("Error creating order: " + ex.Message);
                }
            }
        }

    }
}
